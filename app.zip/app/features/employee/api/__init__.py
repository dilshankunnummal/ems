"""
Employee API package.
"""