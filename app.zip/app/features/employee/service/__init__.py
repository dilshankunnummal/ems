"""
Employee service package.
"""