"""
Employee dependency package.
"""